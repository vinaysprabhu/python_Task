package jp.sourceforge.qrcode.exception;
public class VersionInformationException extends IllegalArgumentException {

}
