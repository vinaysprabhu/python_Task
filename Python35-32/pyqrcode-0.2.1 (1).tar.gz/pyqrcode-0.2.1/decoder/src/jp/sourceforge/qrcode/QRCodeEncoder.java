package jp.sourceforge.qrcode;

public class QRCodeEncoder {

}
